#!/bin/bash

make && qemu-system-x86_64 -fda timeoday.flp -curses

